# Installation
* Use pipenv or make sure to have the python requests library available.
* Make sure to have valid API key by creating a developer account on virustotal website and then accessing your profile for API keys.
# Usage
```
usage: virustotal_api_check_file.py [-h] --key KEY filename

positional arguments:
  filename    File to scan

optional arguments:
  -h, --help  show this help message and exit
  --key KEY   API Key
```

# Tested scenarios
* Random files should be clean. Generate random file from the command line: `head /dev/random > randomFile`
* eicar test file (known positive detection) 
  * `echo 'X5O!P%@AP[4\PZX54(P^)7CC)7}$EICAR-STANDARD-ANTIVIRUS-TEST-FILE!$H+H*' > badFile`
  * `echo $(head /dev/random) 'X5O!P%@AP[4\PZX54(P^)7CC)7}$EICAR-STANDARD-ANTIVIRUS-TEST-FILE!$H+H*' > randomBadFile`
* As the engine doesn't re-check existing files by its md5/sha1 signatures, the code most handle cases when the checks takes longer than with files previously uploaded. (Note the rate limit of 4 requests/minute)