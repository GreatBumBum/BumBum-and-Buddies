#!/usr/bin/env python
import sys
import argparse
import requests
from time import sleep
from pprint import pprint

class VirusTotal_API:
    def __init__(self, apiKey):
        self.apiKey = apiKey

    def uploadFile(self, fileName):
        ''' upload file to virustotal online scanner, and receive its response message'''
        # https://developers.virustotal.com/reference#file-scan
        url = 'https://www.virustotal.com/vtapi/v2/file/scan'
        files = {'file': open(fileName, 'rb')}
        # r = requests.post(url, files=files)
        params = {'apikey': self.apiKey}
        r = requests.post(url, data=params, files=files)

        r.raise_for_status()
        if r.headers['Content-Type'] == 'application/json':
            return r.json()['resource']
        else:
            raise Exception('Unable to locate result')

    def retrieveReport(self, resourceId):
        ''' retrieve report of an existing resource on the virustotal server '''
        # https://developers.virustotal.com/reference#url-report
        url = 'https://www.virustotal.com/vtapi/v2/file/report'
        params = {'apikey': self.apiKey, 'resource': resourceId}
        while True:
            r = requests.get(url, params=params)
            r.raise_for_status()

            if r.headers['Content-Type'] == 'application/json':
                if r.json()['response_code'] == 1: 
                    break
                else:
                    delay = 25
                    sleep(delay)
            else:
                raise Exception('Invalid content type')
        
        report = r.json()
        self.report = report
        positives = []
        for engine, result in report['scans'].items():
            if result['detected'] == True:
                positives.append(engine)
        return positives

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--key', help='API Key', type=str, required=True)
    parser.add_argument('filename', help='File to scan')
    args = parser.parse_args()
    # print(f'Args: {args}')

    api = VirusTotal_API(args.key)
    resourceId = api.uploadFile(args.filename)

    positives = api.retrieveReport(resourceId)

    filename = args.filename
    print(f'Scanned file: {filename}')
    print(f'Positives: {len(positives)}')

    if len(positives) > 0:
        # print(api.report)
        # print(f'WARNING: Found {positives} alerts. Please see the full report above.')
        print(positives)
        sys.exit(1)
    else: 
        sys.exit(0)