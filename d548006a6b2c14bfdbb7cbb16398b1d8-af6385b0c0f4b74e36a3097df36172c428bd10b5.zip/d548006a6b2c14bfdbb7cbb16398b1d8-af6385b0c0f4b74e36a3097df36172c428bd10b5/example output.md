```bash
$ echo 'X5O@AP[4\PZX54(P^)7CC)7}$EICAR-STANDARD-ANTIVIRUS-TEST-FILE!$H+H*' > badFile    
$ python virustotal_api.py --key my.api.key.goes.here badFile
Scanned file: badFile2
Positives: 1
['SUPERAntiSpyware']
```

```bash
$ echo $(head /dev/random) 'X5O@AP[4\PZX54(P^)7CC)7}$EICAR-STANDARD-ANTIVIRUS-TEST-FILE!$H+H*' > randomBadFile
$ python virustotal_api.py --key my.api.key.goes.here randomBadFile
Scanned file: randomBadFile
Positives: 3
['Ikarus', 'MaxSecure', 'Qihoo-360']
```

```bash
$ head /dev/random > randomFile
$ python virustotal_api.py --key my.api.key.goes.here randomFile
Scanned file: randomFile
Positives: 0
```